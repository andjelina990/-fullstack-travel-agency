import Link from 'next/link';
import React from 'react';

function Navbar(props) {
  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-light bg-light">
        <a className="navbar-brand ">
          <i className="fas fa-map-marked-alt" />
          &nbsp;Grand tour
        </a>
        <button
          className="navbar-toggler"
          type="button"
          data-toggle="collapse"
          data-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon" />
        </button>
        <div className="collapse navbar-collapse " id="navbarNav">
          <ul className="navbar-nav ">
            <li className="nav-item active">
              <Link href="/">
                <a className="nav-link">Home</a>
              </Link>
            </li>

            <li className="nav-item">
              <Link href="/destinations">
                <a className="nav-link">Destinations</a>
              </Link>
            </li>
            <li className="nav-item">{props.user && props.user.username}</li>

            <li className="nav-item">
              <div className="btn-group">
                <button
                  type="button"
                  className="btn btn-transparent dropdown-toggle"
                  data-bs-toggle="dropdown"
                  aria-expanded="false"
                >
                  Pick a country
                </button>
                <ul className="dropdown-menu">
                  <Link href="/destinations/1">
                    <a className="dropdown-item">Thailand</a>
                  </Link>

                  <Link href="/destinations/2">
                    <a className="dropdown-item">Bali</a>
                  </Link>
                  <Link href="/destinations/3">
                    <a className="dropdown-item">Venice</a>
                  </Link>
                  <Link href="/destinations/4">
                    <a className="dropdown-item">Maldivi</a>
                  </Link>
                </ul>
              </div>
            </li>
            <li className="nav-item">
              <Link href="/login">
                <a className="nav-link">LOGIN</a>
              </Link>
            </li>
            <li className="nav-item">
              <Link href="/register">
                <a className="nav-link">REGISTER</a>
              </Link>
            </li>
            <li className="nav-item">
              <Link href="/users/private-profile">
                <a className="nav-link">PROFILE</a>
              </Link>
            </li>
            <li className="nav-item">
              <Link href="/logout">
                <a className="nav-link">LOG OUT</a>
              </Link>
            </li>

            <button type="button" className="btn btn-danger">
              Book now
            </button>
          </ul>
        </div>
      </nav>
    </div>
  );
}

export default Navbar;
