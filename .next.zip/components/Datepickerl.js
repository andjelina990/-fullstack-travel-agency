// import React, { useState } from 'react';
// import DatePicker from 'react-datepicker';
// import 'react-datepicker/dist/react-datepicker.css';
// function Datepickerl() {
//   const [selectedDate, setSelectedDate] = useState(null);
//   return (
//     <div>
//       <DatePicker
//         selected={selectedDate}
//         onChange={(date) => setSelectedDate(date)}
//       />
//       <i className="fa fa-calendar " />
//     </div>
//   );
// }

// export default Datepickerl;

import React, { useState } from 'react';
function ImageSlider() {
  // const imgs = [
  //   { id: 0, value: {`/${props.destination.id}.jpg`} },
  //   { id: 1, value: '2.jpg' },
  //   { id: 2, value: 'https://source.unsplash.com/user/c_v_r/100x100' },
  // ];
  const [wordData, setWordData] = useState(imgs[0]);
  const handleClick = (index) => {
    console.log(index);
    const wordSlider = imgs[index];
    setWordData(wordSlider);
  };
  return (
    <div className="main">
      <img src={wordData.value} height="400" width="700" alt="" />
      <div className="flex_row">
        {imgs.map((data, i) => (
          <div className="thumbnail" key={i}>
            <img
              className={wordData.id == i ? 'clicked' : ''}
              src={data.value}
              onClick={() => handleClick(i)}
              height="70"
              width="100"
              alt=""
            />
          </div>
        ))}
      </div>
    </div>
  );
}

export default ImageSlider;
