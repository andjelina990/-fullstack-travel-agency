module.exports = {
  extends: ['@upleveled/upleveled'],
};
