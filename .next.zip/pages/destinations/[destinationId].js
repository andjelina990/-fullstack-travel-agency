import { css } from '@emotion/react';
import Link from 'next/link';
import { getDestinationsAndHotelsById } from '../../util/databaseHa';
// import Image from 'next/image';
// import Link from 'next/link';
// import Datepickerl from '../../components/Datepickerl';
// import { destinations, hotel } from '../../util/database';

const cartt = css`
  display: flex;
  justify-content: space-between;
  flex-wrap: wrap;
  /* article {
    flex: 0 0 24%;
  } */
  a {
    color: black;
    text-decoration: none;
    position: absolute;
    top: 50px;
    left: -50px;
    background-color: #3a8bcd;
    padding: 15px;
    border-radius: 5px;
    color: #fff;
    :hover {
      transform: scale(106%);
    }
  }
`;

// const ulStyle = css`
//   padding-top: 100px;
//   padding-left: 330px;
//   padding-bottom: 100px;
//   text-align: center;
//   /* justify-content: space-between;
//   display: flex; */
// `;

export default function Destination(props) {
  if (!props.destination.length) {
    return <div>We dont have this location</div>;
  }
  console.log(props);

  return (
    <div>
      <h1>{props.destination[0].destination}</h1>

      {props.destination.map((place) => {
        return (
          <div key={`destination-${place.id}`}>
            <Link href={`/hotels/${place.id}`}>
              <a>
                <div> Hotel:{place.name}</div>

                <div> Price:{place.night_price}</div>
                <button className="btn btn-primary mt-3">More</button>
              </a>
            </Link>
          </div>
        );
      })}
    </div>
    /* <div className="row">
        <div className=" ">
          <div
            id="carouselExampleInterval"
            className="carousel slide text-center "
            data-bs-ride="carousel"
          >
            <div className="carousel-inner">
              <div className="carousel-item active " data-bs-interval="10000">
                <video id="videoSl" loop muted autoPlay>
                  <source src="/1.mp4" type="video/webm" />
                </video>
                <div className="carousel-caption d-none d-md-block">
                  <h5 className="display-2">
                    Explore with Maldivi
                    <br /> with US
                  </h5>
                  <p className="lead">
                    Some representative placeholder content for the second
                    slide.
                  </p>
                  <button className="btn btn-lg btn-outline-primary">
                    About us
                  </button>
                  <button className="btn btn-lg btn-outline-primary">
                    Book a tour
                  </button>
                </div>
              </div>
            </div>
            <button
              className="carousel-control-prev"
              type="button"
              data-bs-target="#carouselExampleInterval"
              data-bs-slide="prev"
            >
              <span className="carousel-control-prev-icon" aria-hidden="true" />
              <span className="visually-hidden">Previous</span>
            </button>
            <button
              className="carousel-control-next"
              type="button"
              data-bs-target="#carouselExampleInterval"
              data-bs-slide="next"
            >
              <span className="carousel-control-next-icon" aria-hidden="true" />
              <span className="visually-hidden">Next</span>
            </button>
          </div>
        </div> */

    /* <div className="col-md-3"> */
    /* <Link href={`/hotels/${props.destination[0].id}`}>
            <a>
              <div> Destination:{props.destination[0].name}</div>

              <div> Description:{props.destination[0].description}</div>
              <button className="btn btn-primary mt-3">More</button>
            </a>
          </Link> */
    /* </div> */
    /* <div>
          return  {
          <div>
            {props.hotel
              .filter((person) => person.name === 'thailand')
              .map((filteredPerson) => (
                <li key="">{filteredPerson.name}</li>
              ))}
          </div>
          );
        }

        </div>
      </div> */
    /* </div> */
    /* </div> */
  );
}

export async function getServerSideProps(context) {
  //   // const place = destinations.find((destination) => {
  //   //   return destination.id === context.query.destinationId;
  //   // });
  const destination = await getDestinationsAndHotelsById(
    context.query.destinationId,
  );
  //   // const destination = await getDestinationsById(context.query.destinationId);
  //   // console.log(typeof context.query.destinationId);
  //   // if (!place) {
  //   //   context.res.statusCode = 404;
  //   // }
  //   // const hotels = await hotelDestinationsById(context.query.destinationId);
  console.log(destination);
  return {
    props: {
      destination: destination,

      // destinations: destinations,
    },
  };
}
