import React from 'react';

function Checkout() {
  return <div>checkout</div>;
}

export default Checkout;
