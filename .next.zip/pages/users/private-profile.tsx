import { GetServerSidePropsContext } from 'next';
import Head from 'next/head';
import { getUserByValidSessionToken, User } from '../../util/databaseHa';

type Props = {
  user?: User;
};

export default function UserDetail(props: Props) {
  console.log(props.user);
  if (!props.user) {
    return (
      <>
        <Head>
          <title>User not found</title>
          <meta name="description" content="User not found" />
        </Head>
        <h1>404 - User not found</h1>
        Better luck next time
      </>
    );
  }

  return (
    <div>
      <Head>
        <title>{props.user.username}</title>
        <meta name="description" content="About the app" />
      </Head>

      <main>
        <h1>
          User #{props.user.id} (username: {props.user.username})
        </h1>
        <div>id: {props.user.id}</div>
        <div>username: {props.user.username}</div>
      </main>
    </div>
  );
}

export async function getServerSideProps(context: GetServerSidePropsContext) {
  // if you want to use username in the URL name this variable properly

  // if you want to use username in the URL call function getUserByUsername and don't use parse int
  const user = await getUserByValidSessionToken(
    context.req.cookies.sessionToken,
  );
  // console.log(user);

  if (user) {
    return {
      props: {
        user: user,
      },
    };
  }

  return {
    redirect: {
      destination: `/login?returnTo=/users/private-profile`,
      permanent: false,
    },
  };
}

// exports.up = async (sql) => {
//   await sql`
// 	CREATE TABLE sessions (
// 		id integer PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
// 		token varchar(110) NOT NULL UNIQUE,
// 		expiry_timestamp timestamp  NOT NULL DEFAULT NOW() + INTERVAL '24 hours',
// 		user_id integer REFERENCES users (id) ON DELETE CASCADE

// 		)
// 	`;
// };

// exports.down = async (sql) => {
//   await sql`
// 	DROP TABLE sessions
// 	`;
// };

// exports.up = async (sql) => {
//   await sql`
// 	CREATE TABLE users (
// 		id integer PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
// 		username varchar(90) NOT NULL UNIQUE,
// 		password_hash varchar(90) NOT NULL

// 		)
// 	`;
// };

// exports.down = async (sql) => {
//   await sql`
// 	DROP TABLE users
// 	`;
// };

// exports.up = async (sql) => {
//   await sql`
// 	CREATE TABLE destinations (
// 		id integer PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
// 		name varchar(40) NOT NULL,
// 		description varchar(300) NOT NULL
// 	)

// 	`;
// };

// exports.down = async (sql) => {
//   await sql`
// 	DROP TABLE destinations
// 	`;
// };
