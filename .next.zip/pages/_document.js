import Document, { Html, Head, Main, NextScript } from 'next/document';

class MyDocument extends Document {
  render() {
    return (
      <Html>
        <Head>
          <link
            href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css"
            rel="stylesheet"
            integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3"
            crossOrigin="anonymous"
          />

          <link
            href="https://fonts.googleapis.com/css2?family=Inter&display=optional"
            rel="stylesheet"
          />
          <link
            rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
            integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ=="
            crossOrigin="anonymous"
            referrerpolicy="no-referrer"
          />
        </Head>
        <body>
          <Main />
          <NextScript />
          <script
            src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
            crossOrigin="anonymous"
          />
        </body>
      </Html>
    );
  }
}

export default MyDocument;

// <!DOCTYPE html><html><head><style data-next-hide-fouc="true">body{display:none}</style><noscript data-next-hide-fouc="true"><style>body{display:block}</style></noscript><meta charSet="utf-8"/><meta name="viewport" content="width=device-width"/><meta name="next-head-count" content="2"/><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous"/><link href="https://fonts.googleapis.com/css2?family=Inter&amp;display=optional" rel="stylesheet"/><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ==" crossorigin="anonymous" referrerpolicy="no-referrer"/><noscript data-n-css=""></noscript><script defer="" nomodule="" src="/_next/static/chunks/polyfills.js?ts=1656311739663"></script><script src="/_next/static/chunks/webpack.js?ts=1656311739663" defer=""></script><script src="/_next/static/chunks/main.js?ts=1656311739663" defer=""></script><script src="/_next/static/chunks/pages/_app.js?ts=1656311739663" defer=""></script><script src="/_next/static/chunks/pages/_error.js?ts=1656311739663" defer=""></script><script src="/_next/static/development/_buildManifest.js?ts=1656311739663" defer=""></script><script src="/_next/static/development/_ssgManifest.js?ts=1656311739663" defer=""></script><script src="/_next/static/development/_middlewareManifest.js?ts=1656311739663" defer=""></script><noscript id="__next_css__DO_NOT_USE__"></noscript></head><body><div id="__next"></div><script src="/_next/static/chunks/react-refresh.js?ts=1656311739663"></script><script id="__NEXT_DATA__" type="application/json">{"props":{"pageProps":{"statusCode":500}},"page":"/_error","query":{"__NEXT_PAGE":"/api/register"},"buildId":"development","isFallback":false,"err":{"name":"TypeError","message":"(0 , _util_database__WEBPACK_IMPORTED_MODULE_1__.createUser) is not a function","stack":"TypeError: (0 , _util_database__WEBPACK_IMPORTED_MODULE_1__.createUser) is not a function\n    at handler (webpack-internal:///(api)/./pages/api/register.ts:20:89)\n    at async Object.apiResolver (C:\\Users\\astoj\\OneDrive\\Desktop\\final_project_2\\node_modules\\next\\dist\\server\\api-utils\\node.js:185:9)\n    at async DevServer.runApi (C:\\Users\\astoj\\OneDrive\\Desktop\\final_project_2\\node_modules\\next\\dist\\server\\next-server.js:395:9)\n    at async Object.fn (C:\\Users\\astoj\\OneDrive\\Desktop\\final_project_2\\node_modules\\next\\dist\\server\\base-server.js:496:37)\n    at async Router.execute (C:\\Users\\astoj\\OneDrive\\Desktop\\final_project_2\\node_modules\\next\\dist\\server\\router.js:226:36)\n    at async DevServer.run (C:\\Users\\astoj\\OneDrive\\Desktop\\final_project_2\\node_modules\\next\\dist\\server\\base-server.js:606:29)\n    at async DevServer.run (C:\\Users\\astoj\\OneDrive\\Desktop\\final_project_2\\node_modules\\next\\dist\\server\\dev\\next-dev-server.js:450:20)\n    at async DevServer.handleRequest (C:\\Users\\astoj\\OneDrive\\Desktop\\final_project_2\\node_modules\\next\\dist\\server\\base-server.js:321:20)"},"gip":true,"scriptLoader":[]}</script><script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script></body></html>
