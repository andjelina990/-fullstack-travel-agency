import Cookies from 'js-cookie';
import { GetServerSidePropsContext } from 'next';
import Head from 'next/head';
import Image from 'next/image';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { getParsedCookie, setParsedCookie } from '../../util/cookies';

import { getHotelsById, queryParamToNumber } from '../../util/databaseHa';

type Props = {
  animal: Animal | null;
};

export type NightHotel = {
  id: string;
  eatCounter: number;
};
export default function SingleAnimal(props: Props) {
  const [isInDiet, setInDiet] = useState('eatCounter' in props.animal);
  const [eatCounter, setEatCounter] = useState(props.animal.eatCounter || 0);

  const [currentCoockie, setCurrentCoockie] = useState(
    Cookies.get('night') ? getParsedCookie('night') : [],
  );

  useEffect(() => {
    setParsedCookie('night', currentCoockie);
  }, [currentCoockie]);

  return (
    <div>
      <h1> Hotel:{props.animal.name}</h1>
      <div>Price per Night:{props.animal.nightPrice}</div>

      <div>
        <button
          onClick={() => {
            const currentNight = Cookies.get('night')
              ? getParsedCookie('night')
              : [];
            let newDiet;

            if (
              currentNight.find(
                (nightHotel: NightHotel) => props.animal.id === nightHotel.id,
              )
            ) {
              newDiet = currentNight.filter(
                (nightHotel: NightHotel) => nightHotel.id !== props.animal.id,
              );
              setInDiet(false);

              setEatCounter(0);
            } else {
              newDiet = [
                ...currentNight,
                { id: props.animal.id, eatCounter: 1 },
              ];
              setInDiet(true);
              setEatCounter(1);
            }
            setParsedCookie('night', newDiet);
          }}
        >
          {isInDiet ? 'remove nights' : 'add to nights'}
        </button>
        <br />
        {isInDiet ? (
          <>
            {eatCounter}
            <button
              onClick={() => {
                setEatCounter(eatCounter + 1);
                const currentNight = Cookies.get('night')
                  ? getParsedCookie('night')
                  : [];
                const currentFruitInDiet = currentNight.find(
                  (nightHotel: NightHotel) => props.animal.id === nightHotel.id,
                );
                currentFruitInDiet.eatCounter += 1;
                setParsedCookie('night', currentNight);
              }}
            >
              +
            </button>
            <button
              onClick={() => {
                if (eatCounter > 0) {
                  setEatCounter(eatCounter - 1);
                  const currentDiet = Cookies.get('night')
                    ? getParsedCookie('night')
                    : [];
                  const currentFruitInDiet = currentDiet.find(
                    (nightHotel: NightHotel) =>
                      props.animal.id === nightHotel.id,
                  );
                  currentFruitInDiet.eatCounter -= 1;
                  setParsedCookie('night', currentDiet);
                }
              }}
            >
              -
            </button>
          </>
        ) : (
          ''
        )}{' '}
      </div>

      <Link href="/checkout">
        <a>Book now</a>
      </Link>
    </div>
  );
}

export async function getServerSideProps(context: GetServerSidePropsContext) {
  const animalId = queryParamToNumber(context.query.destinationId);
  const animal = await getHotelsById(animalId);

  if (!animal) {
    context.res.statusCode = 404;
  }
  console.log(animal);

  return {
    props: {
      animal: animal || 0,
    },
  };
}
